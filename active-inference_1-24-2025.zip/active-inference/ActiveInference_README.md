# Active Inference Agent Implementation

## Agentic Mesh Framework Overview

This implementation is part of the Agentic Mesh framework, a microservices-based architecture for building intelligent, distributed agent systems. The framework provides:

### Core Architecture
- **Registry Service**: Central service discovery and management (port 8000)
- **Agent Components**: Modular, specialized agents for different tasks
- **Tool System**: Extensible tool framework for agent capabilities
- **Message Passing**: Asynchronous communication between components

### Key Features
1. **Service Discovery**
   - Dynamic agent registration
   - Automatic service resolution
   - Health monitoring and retry mechanisms

2. **Tool Component System**
   - Standardized tool interfaces
   - Parameter validation
   - Type safety
   - Comprehensive logging

3. **Configuration Management**
   - YAML-based configuration
   - Environment-specific settings
   - Validation rules
   - Dynamic parameter handling

4. **Error Handling**
   - Graceful degradation
   - Retry mechanisms
   - Detailed logging
   - Exception propagation

### Integration Points
1. **Registry Integration**
   - Host: xagenticmesh-registry
   - Port: 8000
   - Retry Configuration: 100 retries, 10-second delay

2. **Tool Component Interface**
   - Standard method implementations
   - Parameter management
   - Return value specifications
   - Execution flow control

3. **Logging System**
   - Structured logging
   - Debug information
   - Error tracking
   - Performance monitoring

### Deployment
The Active Inference agent is deployed as a microservice:
- URL: http://active-inference-agent:8000
- Version: v0.0.1
- Module: tools.brodagroupsoftware.active_inference.tool

### Framework Best Practices
1. **Service Design**
   - Single responsibility principle
   - Clear interface definitions
   - Proper error handling
   - Comprehensive documentation

2. **Configuration Management**
   - Environment-specific settings
   - Clear parameter documentation
   - Validation rules
   - Default values

3. **Monitoring and Logging**
   - Structured log format
   - Performance metrics
   - Error tracking
   - State monitoring

4. **Security**
   - Input validation
   - Safe execution environments
   - Error handling
   - Access control

## Overview
This repository implements an Active Inference agent for Partially Observable Markov Decision Processes (POMDPs) in discrete time and state spaces. The implementation follows the free energy principle and active inference framework developed by Karl Friston and colleagues.

## Theory

### Active Inference Framework
Active Inference is a unified theory of brain function that casts perception, learning, and decision-making as processes of free energy minimization. In this framework:
- Agents maintain probabilistic beliefs about their environment
- Perception is treated as belief updating through variational free energy minimization
- Action selection is performed by minimizing expected free energy
- Both epistemic (information-seeking) and pragmatic (goal-directed) behaviors emerge naturally

### Mathematical Framework

#### Key Components
1. **States (s)**: Hidden states of the environment
2. **Observations (o)**: Sensory inputs available to the agent
3. **Actions (a)**: Possible interventions the agent can make
4. **Time (t)**: Discrete time steps for state transitions and actions

#### Model Matrices
- **A (Likelihood)**: P(o|s) - Mapping from states to observations [n_observations × n_states]
- **B (Transition)**: P(s'|s,a) - State dynamics under actions [n_states × n_states × n_actions]
- **C (Preferences)**: P(o) - Prior preferences over observations [n_observations]
- **D (Initial Beliefs)**: P(s₀) - Initial state distribution [n_states]
- **E (Habits)**: P(a) - Prior preferences over actions/policies [n_actions]

#### Free Energy Equations
1. **Variational Free Energy (F for perception)**:
   F = -ln P(o|s) - ln P(s)
   Where:
   - F is the Variational Free Energy to be minimized
   - P(o|s) from likelihood matrix A (observation model)
   - P(s) from transition matrix B and previous beliefs or initial beliefs D
   - Minimizing F optimizes both accuracy and complexity
   - Lower F indicates better predictions of observations

2. **Expected Free Energy (G for action)**:
   G = Epistemic Value + Pragmatic Value
   Where:
   - Epistemic Value = H[P(s')] - H[P(s)]
     * Expected information gain about hidden states
     * H[P(s)] = -∑ P(s)ln P(s) is state entropy
     * Drives exploration and information-seeking
   - Pragmatic Value = KL[P(o)||C]
     * Divergence between expected observations and preferences
     * P(o) is predicted observations under action
     * C is normalized preference distribution
     * Drives goal-directed behavior

3. **Policy Selection with Habits**:
   P(a) ∝ softmax(-G/τ) * E
   Where:
   - G is expected free energy vector
   - τ is temperature parameter for exploration
   - E is habit prior updated by Bayes rule
   - E_new ∝ P(a|G) * E_old + ε
   - ε is small exploration noise

#### Belief Updating
1. **State Estimation**:
   - Compute free energy for each state given observation
   - Update beliefs using softmax normalization: P(s) = softmax(-F)
   - Track belief history for monitoring

2. **Habit Learning**:
   - Convert expected free energy to action probabilities
   - Update habits using Bayesian inference in log space
   - Add small exploration noise to prevent determinism
   - Maintain running history of action preferences

3. **Numerical Stability**:
   - Log-space computations for products
   - Softmax normalization for probabilities
   - Small epsilon terms to prevent log(0)
   - Temperature scaling for exploration

## Implementation

### Core Components

1. **ActiveInferenceTool Class**
   - Implements the active inference cycle
   - Handles belief updating and action selection
   - Manages model parameters and state
   - Updates and maintains action habits

2. **Key Methods**
   - `_compute_free_energy`: Calculates variational free energy
   - `_update_beliefs`: Updates beliefs using free energy minimization
   - `_compute_expected_free_energy`: Computes expected free energy for actions
   - `_update_policy_prior`: Updates habit matrix based on action outcomes
   - `_select_action`: Chooses actions by combining expected free energy with habits

### Configuration
The system is configured through `ActiveInference_configuration.yaml`, which specifies:
- Agent parameters and structure
- Model dimensions and matrices
- Registry settings for deployment

## Usage

### Installation
```bash
pip install numpy scipy torch
```

### Initialization
```python
from active_inference_tool import ActiveInferenceTool

# Initialize the tool
agent = ActiveInferenceTool()

# Set up initial parameters
parameters = {
    "n_states": 5,
    "n_observations": 3,
    "n_actions": 4,
    "likelihood_matrix": A,  # shape: [n_observations, n_states]
    "transition_matrix": B,  # shape: [n_states, n_states, n_actions]
    "preferences": C,        # shape: [n_observations]
    "initial_beliefs": D,    # shape: [n_states]
    "habit_matrix": E       # shape: [n_actions] (optional)
}

# Initialize the model
result = await agent.execute("init_id", parameters)
```

### Running the Agent
```python
# Update with new observation
result = await agent.execute("step_id", {"observation": current_observation})

# Access results
beliefs = result["beliefs"]
selected_action = result["selected_action"]
free_energy = result["expected_free_energy"]
policy_prior = result["policy_prior"]  # Current habit distribution
```

## Example

Here's a simple example of using the agent in a 2-state POMDP with habit learning:

```python
import numpy as np

# Define a simple 2-state, 2-observation, 2-action POMDP
parameters = {
    "n_states": 2,
    "n_observations": 2,
    "n_actions": 2,
    "likelihood_matrix": np.array([[0.9, 0.1],
                                 [0.1, 0.9]]),
    "transition_matrix": np.array([[[0.9, 0.1],
                                  [0.1, 0.9]],
                                 [[0.1, 0.9],
                                  [0.9, 0.1]]]),
    "preferences": np.array([1.0, 0.0]),
    "initial_beliefs": np.array([0.5, 0.5]),
    "habit_matrix": np.array([0.5, 0.5])  # Initial uniform habits
}

# Initialize and run
agent = ActiveInferenceTool()
result = await agent.execute("init", parameters)
next_result = await agent.execute("step", {"observation": 0})

# Check updated habits
print("Updated action habits:", next_result["policy_prior"])
```

## Advanced Features

### Habit Learning
- Automatic updating of action preferences through experience
- Bayesian integration of past success with current expected free energy
- Numerical stability in probability updates
- History tracking of habit evolution

### Handling Uncertainty
- The implementation includes numerical stability features
- Uses softmax for proper probability normalization
- Includes safety checks for matrix shapes and values

### Logging and Monitoring
- Comprehensive logging of all operations
- Detailed error messages and debugging information
- Performance monitoring through free energy values

## Development

### Adding New Features
1. Extend the `ActiveInferenceTool` class
2. Update configuration in `ActiveInference_configuration.yaml`
3. Add tests for new functionality
4. Update documentation

### Best Practices
- Maintain type hints
- Follow error handling patterns
- Keep logging consistent
- Update configuration when adding parameters

## References

1. Friston, K., FitzGerald, T., Rigoli, F., Schwartenbeck, P., & Pezzulo, G. (2017). Active Inference: A Process Theory. Neural Computation, 29(1), 1-49.
2. Da Costa, L., Parr, T., Sajid, N., Veselic, S., Neacsu, V., & Friston, K. (2020). Active inference on discrete state-spaces: A synthesis. Journal of Mathematical Psychology, 99, 102447.

## License
MIT License - See LICENSE file for details
