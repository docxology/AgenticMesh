import logging
from typing import Dict, Any, List, Tuple, Optional
import numpy as np
from scipy.special import softmax
import torch
import torch.nn.functional as F
import yaml
from datetime import datetime

from tool_component import ToolComponent
import models
from active_inference_utils import ActiveInferenceUtils

logger = logging.getLogger(__name__)

class ActiveInferenceTool(ToolComponent):
    """
    Active Inference POMDP tool for action-perception cycles in discrete time and state spaces.
    Implements free energy minimization for belief updating and action selection.
    
    The implementation follows the mathematical framework from:
    Friston, K., et al. (2017). Active Inference: A Process Theory. Neural Computation, 29(1), 1-49.
    
    Attributes:
        n_states (int): Number of discrete states in the POMDP
        n_observations (int): Number of possible observations
        n_actions (int): Number of possible actions
        A (np.ndarray): Likelihood matrix mapping states to observations
        B (np.ndarray): Transition matrix defining state dynamics under actions
        C (np.ndarray): Prior preferences over observations
        D (np.ndarray): Initial state beliefs
        beliefs (np.ndarray): Current belief distribution over states
        prev_action (int): Previously selected action
    """

    def __init__(self):
        self.tool_parameters: Dict[str, models.ToolParameterModel] = {}
        self._load_parameters()

        self.tool_info = models.ToolInfoModel(
            name="tool.active_inference",
            purpose="Performs Active Inference for POMDPs in discrete time and state spaces.",
            description="Implements Active Inference framework with free energy minimization, belief updating, and action selection for discrete POMDPs.",
            module="tools.brodagroupsoftware.active_inference.tool"
        )

        # Initialize model parameters
        self.n_states: Optional[int] = None
        self.n_observations: Optional[int] = None
        self.n_actions: Optional[int] = None
        
        # Model matrices
        self.A: Optional[np.ndarray] = None  # Likelihood (observation) matrix
        self.B: Optional[np.ndarray] = None  # Transition (dynamics) matrix
        self.C: Optional[np.ndarray] = None  # Prior preferences
        self.D: Optional[np.ndarray] = None  # Initial state beliefs
        self.E: Optional[np.ndarray] = None  # Habit (policy prior) matrix
        
        # Current beliefs and states
        self.beliefs: Optional[np.ndarray] = None
        self.prev_action: Optional[int] = None
        self.policy_prior: Optional[np.ndarray] = None
        
        # History tracking
        self.belief_history: List[np.ndarray] = []
        self.action_history: List[int] = []
        self.free_energy_history: List[float] = []
        self.policy_prior_history: List[np.ndarray] = []

        # Initialize monitoring
        self.metrics = ActiveInferenceUtils.setup_monitoring()
        self.monitoring_enabled = True

    def _validate_parameters(self, parameters: Dict[str, Any]) -> None:
        """Validate input parameters for consistency and correctness."""
        required_params = ["n_states", "n_observations", "n_actions",
                         "likelihood_matrix", "transition_matrix",
                         "preferences", "initial_beliefs"]
        
        # Check for required parameters
        for param in required_params:
            if param not in parameters:
                raise ValueError(f"Missing required parameter: {param}")
        
        # Validate probability distributions
        matrices = {
            "likelihood_matrix": (parameters["likelihood_matrix"], (parameters["n_observations"], parameters["n_states"])),
            "transition_matrix": (parameters["transition_matrix"], (parameters["n_states"], parameters["n_states"], parameters["n_actions"])),
            "preferences": (parameters["preferences"], (parameters["n_observations"],)),
            "initial_beliefs": (parameters["initial_beliefs"], (parameters["n_states"],)),
            "habit_matrix": (parameters["habit_matrix"], (parameters["n_actions"],))
        }
        
        for name, (matrix, shape) in matrices.items():
            matrix = np.array(matrix)
            if matrix.shape != shape:
                raise ValueError(f"Invalid shape for {name}: expected {shape}, got {matrix.shape}")
            
            # Check for valid probability distributions
            if name not in ["preferences", "habit_matrix"]:
                if not np.allclose(matrix.sum(axis=0), 1.0, rtol=1e-5, atol=1e-8):
                    axis_name = "observation" if name == "likelihood_matrix" else "first state"
                    raise ValueError(f"{name} must contain valid probability distributions (sum to 1 along {axis_name} axis)")
            
            # Check for non-negative values
            if name != "preferences":
                if np.any(matrix < 0):
                    raise ValueError(f"{name} contains negative values")

    def _load_parameters(self):
        """Load required parameters for the Active Inference POMDP."""
        logger.info("Loading Active Inference parameters")
        
        # Model structure parameters
        n_states = models.ToolParameterModel(
            name="n_states",
            type="integer",
            description="Number of discrete states in the POMDP"
        )
        n_observations = models.ToolParameterModel(
            name="n_observations",
            type="integer",
            description="Number of possible observations"
        )
        n_actions = models.ToolParameterModel(
            name="n_actions",
            type="integer",
            description="Number of possible actions"
        )
        
        # Model matrices parameters
        likelihood_matrix = models.ToolParameterModel(
            name="likelihood_matrix",
            type="array",
            description="Likelihood matrix A mapping states to observations"
        )
        transition_matrix = models.ToolParameterModel(
            name="transition_matrix",
            type="array",
            description="Transition matrix B defining state dynamics under actions"
        )
        preferences = models.ToolParameterModel(
            name="preferences",
            type="array",
            description="Prior preferences C over observations"
        )
        initial_beliefs = models.ToolParameterModel(
            name="initial_beliefs",
            type="array",
            description="Initial belief distribution D over states"
        )
        habit_matrix = models.ToolParameterModel(
            name="habit_matrix",
            type="array",
            description="Habit matrix E defining prior preferences over actions/policies"
        )
        
        # Add all parameters
        parameters = [n_states, n_observations, n_actions, 
                     likelihood_matrix, transition_matrix, 
                     preferences, initial_beliefs, habit_matrix]
        for param in parameters:
            self.tool_parameters[param.name] = param

    def _initialize_model(self, parameters: Dict[str, Any]):
        """Initialize the Active Inference model with given parameters."""
        # Validate parameters first
        self._validate_parameters(parameters)
        
        self.n_states = parameters["n_states"]
        self.n_observations = parameters["n_observations"]
        self.n_actions = parameters["n_actions"]
        
        # Convert matrices to numpy arrays and ensure proper shapes
        self.A = np.array(parameters["likelihood_matrix"])
        self.B = np.array(parameters["transition_matrix"])
        self.C = np.array(parameters["preferences"])
        self.D = np.array(parameters["initial_beliefs"])
        
        # Initialize habit matrix (E) with uniform distribution if not provided
        if "habit_matrix" in parameters:
            self.E = np.array(parameters["habit_matrix"])
            # Normalize to ensure it sums to 1
            self.E = self.E / (self.E.sum() + 1e-16)
        else:
            self.E = np.ones(self.n_actions) / self.n_actions
        
        # Initialize beliefs and policy prior
        self.beliefs = self.D.copy()
        self.policy_prior = self.E.copy()
        self.prev_action = None
        
        # Reset history
        self.belief_history = [self.beliefs.copy()]
        self.action_history = []
        self.free_energy_history = []
        self.policy_prior_history = [self.policy_prior.copy()]

    def _compute_free_energy(self, observation: int) -> np.ndarray:
        """
        Compute variational free energy (F) for belief updating.
        
        The variational free energy F is defined as:
        F = -ln P(o|s) - ln P(s)
        where:
        - F is the variational free energy to be minimized
        - P(o|s) is the likelihood from matrix A
        - P(s) is the prior from previous beliefs or initial beliefs D
        
        Args:
            observation: Current observation index
            
        Returns:
            F: Variational free energy for each possible state
        """
        # Compute likelihood term: -ln P(o|s)
        log_likelihood = np.log(self.A[observation, :] + 1e-16)
        F_likelihood = -log_likelihood  # Negative log likelihood
        
        # Compute prior term: -ln P(s)
        if self.prev_action is not None:
            prior = self.B[:, :, self.prev_action] @ self.beliefs
            log_prior = np.log(prior + 1e-16)
        else:
            log_prior = np.log(self.D + 1e-16)
        F_prior = -log_prior  # Negative log prior
            
        # Total variational free energy
        F = F_likelihood + F_prior
        
        # Log for monitoring
        logger.debug(f"F_likelihood: {F_likelihood.mean():.4f}, F_prior: {F_prior.mean():.4f}, Total F: {F.mean():.4f}")
        
        return F

    def _update_beliefs(self, observation: int):
        """
        Update beliefs by minimizing variational free energy F.
        
        Uses softmax to convert free energy F to posterior probabilities:
        P(s|o) ∝ exp(-F)
        """
        F = self._compute_free_energy(observation)
        self.beliefs = softmax(-F)  # Minimize F through softmax
        self.belief_history.append(self.beliefs.copy())
        self.free_energy_history.append(float(F.mean()))

    def _compute_expected_free_energy(self) -> np.ndarray:
        """
        Compute expected free energy for action selection.
        
        The expected free energy (G) combines:
        G = Epistemic Value + Pragmatic Value
        where:
        1. Epistemic Value: Expected information gain about hidden states
           - Measures how much uncertainty about states would be resolved
           - Drives exploration and information-seeking behavior
        2. Pragmatic Value: Expected alignment with preferences
           - Measures how well expected observations match preferences
           - Drives goal-directed behavior
        
        Returns:
            Expected free energy for each possible action
        """
        G = np.zeros(self.n_actions)
        epsilon = 1e-16  # Numerical stability constant
        
        for a in range(self.n_actions):
            # Predicted states under action
            predicted_states = self.B[:, :, a] @ self.beliefs
            
            # Expected observations
            expected_obs = self.A @ predicted_states
            
            # 1. Epistemic Value (Expected Information Gain)
            # Compute state entropy difference
            predicted_state_entropy = -(predicted_states * np.log(predicted_states + epsilon)).sum()
            current_entropy = -(self.beliefs * np.log(self.beliefs + epsilon)).sum()
            epistemic_value = predicted_state_entropy - current_entropy
            
            # 2. Pragmatic Value (Preference Alignment)
            # KL divergence between expected observations and preferences
            normalized_pref = np.exp(self.C) / (np.exp(self.C).sum() + epsilon)
            pragmatic_value = -(expected_obs * np.log(normalized_pref + epsilon)).sum()
            
            # Combine values (negative because we want to maximize epistemic value and minimize pragmatic cost)
            G[a] = -epistemic_value + pragmatic_value
            
        return G

    def _update_policy_prior(self, G: np.ndarray):
        """
        Update policy prior (habits) based on expected free energy.
        Uses Bayesian updating in log space for numerical stability.
        
        Args:
            G: Expected free energy for each action
        """
        # Convert expected free energy to probability distribution (lower G = higher probability)
        # Temperature parameter could be made configurable
        temperature = 1.0
        policy_likelihood = softmax(-G / temperature)
        
        # Update policy prior using Bayes rule (in log space for numerical stability)
        log_posterior = np.log(policy_likelihood + 1e-16) + np.log(self.policy_prior + 1e-16)
        
        # Softmax for numerical stability and proper normalization
        self.policy_prior = softmax(log_posterior)
        
        # Add small noise to prevent complete determinism (optional)
        noise = np.random.dirichlet(np.ones(self.n_actions) * 100)  # High concentration = small noise
        self.policy_prior = 0.99 * self.policy_prior + 0.01 * noise
        
        # Store in history
        self.policy_prior_history.append(self.policy_prior.copy())

    def _select_action(self) -> int:
        """
        Select action by minimizing expected free energy and updating habits.
        
        Returns:
            Selected action index
        """
        # Compute expected free energy
        G = self._compute_expected_free_energy()
        
        # Update policy prior (habits)
        self._update_policy_prior(G)
        
        # Select action using updated policy prior
        action_probs = softmax(-G) * self.policy_prior  # Combine EFE with habits
        action_probs = action_probs / (action_probs.sum() + 1e-16)  # Normalize
        
        # Sample action from the resulting distribution
        action = int(np.argmax(action_probs))  # Could also use random sampling here
        self.action_history.append(action)
        return action

    def get_history(self) -> Dict[str, Any]:
        """
        Get the history of beliefs, actions, free energies, and policy priors.
        
        Returns:
            Dictionary containing historical data
        """
        return {
            "belief_history": [b.tolist() for b in self.belief_history],
            "action_history": self.action_history,
            "free_energy_history": self.free_energy_history,
            "policy_prior_history": [p.tolist() for p in self.policy_prior_history]
        }

    def return_value(self) -> models.ToolReturnValueModel:
        """Define return value structure."""
        return models.ToolReturnValueModel(
            type="dict",
            description="Returns current beliefs, selected action, free energies, and history"
        )

    async def execute(self, iid: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute one step of the Active Inference cycle.
        
        Args:
            iid: Instance ID
            parameters: Must contain model parameters on first call, 
                       and observation for subsequent calls
                       
        Returns:
            Dictionary containing:
            - beliefs: Current belief distribution over states
            - selected_action: Selected action index
            - expected_free_energy: EFE for each action
            - policy_prior: Current habit distribution
            - history: Complete history of beliefs, actions, free energies, and habits
        """
        logger.info(f"Active Inference tool iid:{iid} with parameters: {parameters}")

        try:
            # Validate input
            ActiveInferenceUtils.validate_input(parameters)
            
            # Initialize model if not already initialized
            if self.n_states is None:
                self._initialize_model(parameters)
                logger.info("Initialized Active Inference model")
                
            # Update beliefs based on observation if provided
            if "observation" in parameters:
                observation = parameters["observation"]
                if not 0 <= observation < self.n_observations:
                    raise ValueError(f"Invalid observation index: {observation}")
                self._update_beliefs(observation)
                logger.info(f"Updated beliefs based on observation {observation}")

            # Select action and update habits
            G = self._compute_expected_free_energy()
            self._update_policy_prior(G)
            action = self._select_action()
            self.prev_action = action
            
            # Record metrics if enabled
            if self.monitoring_enabled:
                ActiveInferenceUtils.record_metrics(self.metrics, self.free_energy_history[-1])
            
            # Return results
            output = {
                "beliefs": self.beliefs.tolist(),
                "selected_action": int(action),
                "expected_free_energy": G.tolist(),
                "policy_prior": self.policy_prior.tolist(),
                "history": self.get_history()
            }
            
            msg = (
                "\n *********"
                "\n *"
                "\n * " + f"Tool: {self.tool_info.name}"
                "\n * " + f"Active Inference step iid:{iid}"
                "\n * " + f"Output: {str(output)[:100] + '...' + f' (total length: {len(str(output))})' if len(str(output)) > 100 else str(output)}"
                "\n *"
                "\n *********"
            )
            logger.info(msg)
            return output
            
        except Exception as e:
            error_state = {
                'beliefs': self.beliefs.tolist() if self.beliefs is not None else None,
                'last_action': self.prev_action,
                'policy_prior': self.policy_prior.tolist() if self.policy_prior is not None else None
            }
            ActiveInferenceUtils.handle_error(e, "Execution error", error_state)
            raise

