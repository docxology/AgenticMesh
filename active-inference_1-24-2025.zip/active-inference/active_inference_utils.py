"""
Active Inference Utilities Module

Provides shared functionality and helper methods for Active Inference components.
"""

import logging
import yaml
from datetime import datetime
from typing import Dict, Any, List, Optional
import numpy as np
import torch

logger = logging.getLogger(__name__)

class ActiveInferenceUtils:
    """Utility class for Active Inference operations"""
    
    @staticmethod
    def load_configuration(config_path: str) -> Dict:
        """Load and validate configuration from YAML file"""
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f)
                ActiveInferenceUtils.validate_configuration(config)
                return config
        except Exception as e:
            logger.error(f"Configuration loading failed: {e}")
            raise

    @staticmethod
    def validate_configuration(config: Dict) -> None:
        """Validate configuration structure and values"""
        required_sections = ['model', 'registry', 'monitoring']
        for section in required_sections:
            if section not in config:
                raise ValueError(f"Missing configuration section: {section}")

    @staticmethod
    def setup_monitoring() -> Dict:
        """Initialize monitoring metrics"""
        return {
            'free_energy': [],
            'belief_updates': 0,
            'action_selections': 0
        }

    @staticmethod
    def record_metrics(metrics: Dict, free_energy: float) -> None:
        """Update monitoring metrics"""
        metrics['free_energy'].append(free_energy)
        metrics['belief_updates'] += 1
        metrics['action_selections'] += 1

    @staticmethod
    def validate_input(parameters: Dict) -> None:
        """Validate and sanitize input parameters"""
        if not isinstance(parameters, dict):
            raise ValueError("Parameters must be a dictionary")
        
        # Check for malicious content
        for key, value in parameters.items():
            if isinstance(value, str) and any(char in value for char in [';', '|', '&']):
                raise ValueError(f"Invalid characters in parameter {key}")

    @staticmethod
    def handle_error(error: Exception, context: str = "", state: Optional[Dict] = None) -> Dict:
        """Standardized error handling"""
        error_info = {
            'timestamp': datetime.now().isoformat(),
            'error_type': type(error).__name__,
            'message': str(error),
            'context': context,
            'state': state or {}
        }
        logger.error(f"Error occurred: {error_info}")
        return error_info

    @staticmethod
    def optimize_computations(matrices: Dict[str, np.ndarray]) -> Dict[str, torch.Tensor]:
        """Optimize matrix operations using GPU if available"""
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        return {name: torch.tensor(matrix, device=device) for name, matrix in matrices.items()}

    @staticmethod
    def generate_examples() -> List[Dict]:
        """Generate usage examples"""
        return [
            {
                'description': 'Simple 2-state POMDP',
                'parameters': {
                    'n_states': 2,
                    'n_observations': 2,
                    'n_actions': 2,
                    'likelihood_matrix': [[0.9, 0.1], [0.1, 0.9]],
                    'transition_matrix': [[[0.9, 0.1], [0.1, 0.9]], [[0.1, 0.9], [0.9, 0.1]]],
                    'preferences': [1.0, 0.0],
                    'initial_beliefs': [0.5, 0.5]
                }
            }
        ] 